﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BLL.Public
{
    /*
     * 每个窗体都要用到的验证
     * 设计目的：为了每次进入新的窗体时，验证Token令牌的有效性
     */
    public class B_Validate
    {

    }
}
